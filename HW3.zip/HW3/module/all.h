#ifndef ALL_H
#define ALL_H

#include <linux/cdev.h>
#include <linux/platform_device.h>
#include <linux/delay.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/slab.h>
#include <linux/ioctl.h>
#include <linux/kernel.h>
#include <linux/ioport.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/version.h>
#include <linux/device.h>
#include <linux/interrupt.h>
#include <linux/sched.h>

#include <asm/irq.h>
#include <mach/gpio.h>
#include <asm/gpio.h>

#include <asm/io.h>
#include <asm/uaccess.h>


#include "device.h"
#include "timer_driver.h"


#endif